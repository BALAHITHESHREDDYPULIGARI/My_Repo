import React from "react";

function Skills() {
  return (
    <div>
      <section id="skills" className="skills">
        <h2>Skills</h2>
        <div className="skills-list">
          <span className="skill">HTML</span>
          <span className="skill">CSS</span>
          <span className="skill">JavaScript</span>
          {/* Add more skills as needed */}
        </div>
      </section>
    </div>
  );
}

export default Skills;
