// Theme toggle functionality
import { useState } from "react";

function App() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleTheme = () => {
    setDarkMode(!darkMode);
    document.body.classList.toggle("dark-theme");
  };

  return (
    <div className={`App ${darkMode ? "dark" : ""}`}>
      <Header toggleTheme={toggleTheme} />
      <main>...</main>
    </div>
  );
}
