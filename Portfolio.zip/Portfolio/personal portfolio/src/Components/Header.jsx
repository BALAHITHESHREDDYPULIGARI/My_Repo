import React from "react";

function Header() {
  return (
    <header className="Header">
      <div>
        <nav>
          <ul>
            <li>
              <a href="#about">About Me</a>
            </li>

            <li>
              <a href="#skills">Skills</a>
            </li>

            <li>
              <a href="#projects">Projects</a>
            </li>

            <li>
              <a href="#contact">Contact</a>
            </li>
          </ul>
        </nav>
      </div>
      <button id="theme-toggle">Toggle Theme</button>
    </header>
  );
}

export default Header;
