import React from "react";

function About() {
  return (
    <div>
      <section id="about" className="about">
        <h2>About Me</h2>
        <img src="/path/to/profile.jpg" alt="Profile" />
        <p>
          Hello! I’m [Your Name], a [Your Profession/Field] with a passion for
          coding and design.
        </p>
      </section>
    </div>
  );
}
export default About;
